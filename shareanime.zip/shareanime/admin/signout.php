<?php 
require_once 'core/init.php';
$session->EndSession();
new redirect($_DOMAIN);
 ?>