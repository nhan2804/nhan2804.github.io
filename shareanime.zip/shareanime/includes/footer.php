 			</div>
 		</div>
	</div>
	<div class="footer">
	<div class="gird wide">
		<div class="row">
			<div class="col lg-3 md-4 sm-6">
				<h3 class="footer-heading">Giới thiệu</h3>
				<ul class="footer-list">
				    <li class="footer-item">
				    	<a class="footer-link" href="#">Trung tâm trợ giúp</a>
				    	<a class="footer-link" href="#">Thắc mắc</a>
				    	<a class="footer-link" href="#">Hỗ trợ chi tiết</a>
				    </li>
				</ul>
			</div>
			<div class="col lg-3 md-4 sm-6">
				<h3 class="footer-heading">Danh mục</h3>
				<ul class="footer-list">
				    <li class="footer-item">
				    	<a class="footer-link" href="#">Truyện tranh</a>
				    	<a class="footer-link" href="#">Tiểu thuyết</a>
				    	<a class="footer-link" href="#">Phim</a>
				    </li>
				</ul>
			</div>
			<div class="col lg-3 md-4 sm-6">
				<h3 class="footer-heading">Theo dõi</h3>
				<ul class="footer-list">
				    <li class="footer-item">
				    	<a class="footer-link" href="https://www.facebook.com/anhimdi" target="blank"><i style="color: #3b5998" id="social-fb" class="fa fa-facebook-square fa-3x social"></i><span class="social-space">Facebook</span></a>
				    </li>
				    <li class="footer-item">
				    	<a target="blank" class="footer-link" href="#"><i style="color: #55acee"  id="social-tw" class="fa fa-twitter-square fa-3x social"></i>
				    	<span class="social-space">Twitter</span></a>
				    </li>
				    <li class="footer-item">
				    	<a target="blank" class="footer-link" href="https://www.pinterest.com/akainu345/"><i style="color: #bd081c" id="social-em" class="fa fa-pinterest-square fa-3x social"></i>
				    	<span class="social-space">Pinterest</span></a>
				    </li>
				</ul>
			</div>
			<div class="col lg-3 md-4 sm-6">
				<h3 class="footer-heading">Nhận thông báo</h3>
				<p>Nhập Gmail của bạn để chúng tôi gửi những thông báo mới nhất</p>
				<input class="footer-input" type="text" name="gmail" placeholder="Nhập Gmail của bạn"><br><br>
				<input class="btn btn-primary" type="submit" name="sub" value="Gửi">
			</div>
		</div>
	</div>
	<div class="gird wide">
		<div class="row">
			<div class="footer-end">
			<p>Trải nghiệm thế giới truyện tranh hoàn toàn miễn phí</p>
			<p>Liên hệ quảng cáo Email: contact.shareanime@gmail.com</p>
			<p >© 2020 - Bản quyền thuộc về Nguyễn Ngọc Nhẫn. All rights reserved.</p>
			</div>
		</div>
	</div>
</div>
</div>
    </body>
    <script src="<?php echo $_DOMAIN; ?>js/jquery.min.js"></script>
 	<script src="<?php echo $_DOMAIN; ?>js/form.js"></script>
</html>