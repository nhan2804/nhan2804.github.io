<?php
$title_error_404='Không tìm thấy trang yêu cầu!';
if (isset($_GET['sp']) && isset($_GET['id']) && isset($_GET['ct'])) {
		$sp = trim(htmlspecialchars(addslashes($_GET['sp'])));
		$id = trim(htmlspecialchars(addslashes($_GET['id'])));
		$ct = trim(htmlspecialchars(addslashes($_GET['ct'])));
		$sql_get_lightnovel = "SELECT * FROM lightnovel WHERE id_lightnovel = '$id'";
		$data_lightnovel = $db->getRow($sql_get_lightnovel);
		$name_ln =$data_lightnovel['name_lightnovel'];
		$sql_get_chapter = "SELECT * from chapter WHERE id_lightnovel=$id";
		$data_chapter = $db->getRow($sql_get_chapter);
		$name_chapter= $data_chapter['Name_Chapter'];
		$title = $name_ln.'-'.$name_chapter;
}
else if(isset($_GET['sp']) && isset($_GET['id'])) {
	$slug= trim(addslashes(htmlspecialchars($_GET['sp'])));
	$id= trim(addslashes(htmlspecialchars($_GET['id'])));
	$sql_check_slug_id= "SELECT * from posts where slug='$slug' and id_post='$id'";
	if ($db->numrow($sql_check_slug_id)) {
		$data_slug_id = $db->getRow($sql_check_slug_id);
		$title= $data_slug_id['title'];
	}else{
		$title= $title_error_404;
	}
}else if (isset($_GET['sc']) ) {
	$slug_cate = trim(htmlspecialchars($_GET['sc']));
	$sql_check_slug= "SELECT * from categories where url='$slug_cate'";
	if ($db->numrow($sql_check_slug)) {
		$data_slug = $db->getRow($sql_check_slug);
		$title= $data_slug['label'];
	}else{
        $title = $title_error_404;
	}
}else{
	$title=$title_web;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css"/>
    <link rel="stylesheet" href="<?php echo $_DOMAIN; ?>js/layout.css">
    <link rel="stylesheet" href="<?php echo $_DOMAIN; ?>js/responsive.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $_DOMAIN; ?>js/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v6.0"></script>
<a href="javascript:void(0)"><div class="page"><i class="fas fa-angle-double-up"></i></i></div></a>
<div class="web">
	<div class="header">
		<div class="gird wide">
			<div class="menu_cate">
			<a href="<?php echo $_DOMAIN ?>"><h3 style="font-size: 1.4rem;">ShareAnime</h3></a>
			<ul class="menu1">
				<?php
				$sql_get_list_menu_1 = "SELECT * FROM categories WHERE type = '1' and sort!='100' ORDER BY sort ASC";
				if ($db->numrow($sql_get_list_menu_1)) {
				 	foreach ($db->getData($sql_get_list_menu_1) as $key => $value1) {
				 		$sql_get_list_menu_2 = "SELECT * FROM categories WHERE type = '2' AND parent_id = '$value1[id_cate]' ORDER BY sort ASC";
				 		if ($db->numrow($sql_get_list_menu_2)) {
				 			$sub_menu2 = '<ul class="menu2">';
				 			foreach ($db->getData($sql_get_list_menu_2) as $key => $value2) {
				 				$sql_get_list_menu_3 = "SELECT * FROM categories WHERE type = '3' AND parent_id = '$value2[id_cate]' ORDER BY sort ASC";
				 				if ($db->numrow($sql_get_list_menu_3)) {
				 					$sub_menu3 = '<ul class="menu3">';
				 					foreach ($db->getData($sql_get_list_menu_3) as $key => $value3) {
				 						$sub_menu3 .= '<li class="cate_list_sub"><a class="cate_link_sub" href="'.$_DOMAIN.'categories/'.$value3['url'].'">'.$value3['label'].'</a></li>' ;
				 					}
				 					$sub_menu3.='</ul>';
				 					$sub_menu2 .= '<li class="cate_list_sub"><a class="cate_link_sub" href="'.$_DOMAIN.'categories/'.$value2['url'].'">'.$value2['label'].'<span class="right-span fas fa-angle-right"></span>'.$sub_menu3.'</a></li>' ;
				 				}else{
				 					$sub_menu3='';
				 					$sub_menu2 .= '<li class="cate_list_sub"><a class="cate_link_sub" href="'.$_DOMAIN.'categories/'.$value2['url'].'">'.$value2['label'].''.$sub_menu3.'</a></li>' ;
				 				}
				 			}
				 			$sub_menu2 .='</ul>';
				 			echo '
								<li class="cate_list"><a class="cate_link" href="'.$_DOMAIN.'categories/'.$value1['url'].'">'.$value1['label'].'<span class="space-icon fas fa-angle-down"></span>'.$sub_menu2.'</a></li>
				 			';
				 		}else{
				 			$sub_menu2 ='';
				 			echo '
								<li class="cate_list"><a class="cate_link" href="'.$_DOMAIN.'categories/'.$value1['url'].'">'.$value1['label'].' '.$sub_menu2.'</a></li>
				 			';
				 		}
				 	}
				 	echo '<li class="cate_list"><a class="cate_link" href="'.$_DOMAIN.'news/1">TIN TỨC</a></li>';
				 	echo '<li class="cate_list"><a href="'.$_DOMAIN.'intro/us.html" class="cate_link">GIỚI THIỆU</a></li>';
				 	if ($user) {
				 		if (isset($_GET['sc']) || isset($_GET['in']) || isset($_GET['n'])) {
							$url_img='../';
						}else if (isset($_GET['ct'])) {
							$url_img='../../';
						}else{
							$url_img='';
						}
				 		echo "</ul>";
				 		$sql_get_name= "SELECT * from accounts where username='$user'";
				 		$data_get_name = $db->getRow($sql_get_name);
				 		$display_name= $data_get_name['display_name'];
				 		$img_user = $data_get_name['url_avatar'];
				 		echo '<div class=" user">
				 		<img class="img_user" src="'.$url_img.$img_user.'" alt="f" />
				 		<a style="margin-left:4px;" href="'.$_DOMAIN.'admin/" class="">'.$display_name.'</a></div>';
				 	}else{
				 	echo '<li class="cate_list"><a href="'.$_DOMAIN.'admin/" class="cate_link">Đăng nhập</a></li>';
				 	echo "</ul>";
					 }
				} 

				?>
			
			<button class="btn btn-search"><i class="fas fa-search"></i>
			</button>
			<form class="form_input-search" action="<?php echo $_DOMAIN; ?>" method="GET">
				<div class="input_search">
					<input type="text" name="search" placeholder="Nhập tên,thể loại cần tìm..."/>
					<button class="btn"><i class="fas fa-search"></i></button>
				</div>
			</form>
		</div>
	</div>
	</div>
	<div class="gird wide">
	<div class="row space">
		
