$_DOMAIN = 'http://localhost/newspage';
function opentab(evt,id) {
	var tabcontent,active;
	tabcontent = document.getElementsByClassName("list_popular");
	for (var i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = 'none';
	}
	active = document.getElementsByClassName("opentab");
	for (var i = 0; i < active.length; i++) {
		active[i].className = active[i].className.replace("active","");
	}
	document.getElementById(id).style.display = 'block';
	evt.currentTarget.className+= " active";
}
if (document.getElementById("opened")) {
	document.getElementById("opened").click();
}

$('.page').click(function() {
	$('body,html').animate({
	scrollTop: 0
	})
	});
	$(window).scroll(function () {
	var e = $(window).scrollTop();
	if (e > 300) {
		$(".page").show();
	} else {
		$(".page").hide();
	}
});
$(window).scroll(function () {
	var e = $(window).scrollTop();
	if (e > 120) {
		$(".header").css({
			position : 'fixed',
			top: '0',
			left: '0',
			right : '0'
		});
	} else {
		$(".header").css('position', 'unset');
	}
});
$(window).scroll(function () {
	var e = $(window).scrollTop();
	if (e > 120 ) {
		$(".header").css({
			position : 'fixed',
			top: '0',
			left: '0',
			right : '0'
		});
	}
});
	