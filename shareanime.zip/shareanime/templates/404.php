<div class="container">
    <div class="row">
        <div class="col md-12 lg-12">
        	<h1 style="color: red;">OOPS! Trang này không tồn tại</h1>
        <a style="display: block" href="<? php echo $_DOMAIN; ?>">Trở về trang chủ</a>
        </div>
    </div>
</div>