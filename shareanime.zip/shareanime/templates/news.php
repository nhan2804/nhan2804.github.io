<div class="col lg-9 md-12">
    <span style="font-size: 1.4rem;color: #F31010">CHIA SẺ VỚI BẠN BÈ </span><div class="fb-share-button" data-href="https://www.facebook.com/IshtarFanArt" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.facebook.com%2FIshtarFanArt&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Chia sẻ </a></div>
    <h3>Tin mới nhất</h3>
	<div class="row">
	<?php 
	$sqlGetpost = "SELECT id_post FROM posts WHERE status = '1'";
    $countPost = $db->numrow($sqlGetpost);
    if (isset($_GET['p'])) {
    	$page = trim(addslashes(htmlspecialchars($_GET['p'])));
    	if (preg_match('/\d/', $page )) {
    		$page=$page;
    	}else{
    		$page=1;
    	}
    }else{
    	$page=1;
    }
    $limit = 10;
    $totalPage=ceil($countPost/$limit);
    if ($page>$totalPage) {
    	$page=$totalPage;
    }else if ($page<1) {
    	$page=1;
    }
    $start=($page-1)*$limit;
    $sql_get_news = "SELECT * FROM posts WHERE status = '1' ORDER BY id_post DESC LIMIT $start, $limit";
    if ($db->numrow($sql_get_news)) {
    	foreach ($db->getData($sql_get_news) as $key => $value) {
    	echo '
            <div class="col md-12 lg-12 sm-12 margin">
                <div class="row">
                    <div class="col md-4 lg-4 sm-12">
                        <div class="img_news">
                        <img src="'.$value['url_thumb'].'" alt="'.$value['url_thumb'].'">
                        <h4 class="tintucanime">TIN TỨC ANIME</h4>
                        </div>
                    </div>
                    <div class="col md-8 lg-8 sm-12">
                        <a href="'.$_DOMAIN.$value['slug'].'-'.$value['id_post'].'.html"><h3 style="margin-top:0;">'.$value['title'].'</h3></a>
                        <div>
                            <p>'.$value['descr'].'</p>
                            <i>'.$value['date_posted'].'</i>
                        </div>
                    </div>
                </div>
            </div>
            ';
    	}
    }else{
    	echo "<div >
    		<h3>Hiện không có bài viết nào</h3>
    	</div>";
    }
    echo "</div>
    <h3>Light Novel</h3>
    ";

    $sql_get_ln = "SELECT * FROM lightnovel ORDER BY id_lightnovel DESC";
    echo '<div class="row">';
    if ($db->numrow($sql_get_ln)) {
        foreach ($db->getData($sql_get_ln) as $key => $value1) {
            $sql_get_new_chapter = "SELECT  Num_Chapter,Name_Chapter from chapter WHERE Id_lightnovel='$value1[id_lightnovel]' ORDER BY  Num_Chapter DESC";
            $data_new_chap =$db->getRow($sql_get_new_chapter );
            $new_chap = $data_new_chap['Num_Chapter'];
        echo '
            <div class="col md-3 lg-3 sm-12 margin">
                <div class="post">
                    <div class="title_img">
                        <a href="'.$_DOMAIN.'lightnovel/'.$value1['url_lightnovel'].'-'.$value1['id_lightnovel'].'.html">
                            <img class="img_post" width="auto" height="100px" src="'.$value1['img_lightnovel'].'" alt="ssssss">
                        </a>
                    </div>
                    <div class="descr_post">
                    <a href="'.$_DOMAIN.'lightnovel/'.$value1['url_lightnovel'].'-'.$value1['id_lightnovel'].'/'.$new_chap.'.html"><h4>'.$value1['name_lightnovel'].'</h4></a>
                        <p class="descr_text">'.$value1['descr_lightnovel'].'</p>
                    </div>
                    <h3 class="title_post">'.$value1['name_lightnovel'].'</h3>
                </div>
            </div>
            
            ';
        }
    }
    echo "</div>";
    if ($page>1 && $totalPage>1) {
    	echo '
                <a href="' . $_DOMAIN . ($page - 1 ) . '" class="pagination">
                    <span class="fas fa-angle-left"></span> Pre
                </a>
            ';
    }
	  for ($i=1; $i <=$totalPage ; $i++) {
	  	if ($i == $page){
	        echo '<a class="pagination active">'.$i.'</a>';
	    } else {
	        echo '
	            <a href="' . $_DOMAIN . $i . '" class="pagination">
	                ' . $i . '
	            </a>';
	    }
	  }
	  if ($page<$totalPage && $totalPage>1) {
	  	echo '
                <a href="' . $_DOMAIN . ($page - 1 ) . '" class="pagination">
                    Next<span class="fas fa-angle-right"></span>
                </a>
            ';
	  }
	 ?>
    
</div>